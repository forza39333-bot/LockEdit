package com.lockedit.app;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.text.format.DateFormat;
import java.io.File;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class CustomClockWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new ClockEngine(); }
    private class ClockEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean visible;
        private final Runnable drawTask = new Runnable() { @Override public void run() { drawFrame(); } };
        @Override public void onVisibilityChanged(boolean v) { visible = v; if (v) drawFrame(); else handler.removeCallbacks(drawTask); }
        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) { super.onSurfaceChanged(holder, format, width, height); drawFrame(); }
        @Override public void onSurfaceDestroyed(SurfaceHolder holder) { visible = false; handler.removeCallbacks(drawTask); super.onSurfaceDestroyed(holder); }
        @Override public void onDestroy() { visible = false; handler.removeCallbacks(drawTask); super.onDestroy(); }
        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder(); Canvas canvas = null;
            try {
                canvas = holder.lockCanvas(); if (canvas == null) return;
                android.content.SharedPreferences p = getSharedPreferences("custom_live_clock", MODE_PRIVATE);
                String path = p.getString("image", ""); Bitmap bg = path.isEmpty() ? null : BitmapFactory.decodeFile(path);
                if (bg != null) { RectF dst = new RectF(0,0,canvas.getWidth(),canvas.getHeight()); canvas.drawBitmap(bg,null,dst,new Paint(Paint.FILTER_BITMAP_FLAG)); bg.recycle(); }
                else canvas.drawColor(Color.rgb(15,20,28));
                int alpha = p.getInt("alpha",100) * 255 / 100;
                int color; try { color = Color.parseColor(p.getString("color", "#FFFFFF")); } catch (Throwable t) { color = Color.WHITE; }
                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG); paint.setColor(color); paint.setAlpha(alpha); paint.setTextAlign(Paint.Align.CENTER);
                int size = p.getInt("size",68); float scaleX = p.getInt("width",100)/100f; float x = canvas.getWidth()*p.getInt("x",50)/100f; float y = canvas.getHeight()*p.getInt("y",22)/100f;
                String fontPath = p.getString("font", ""); Typeface typeface = Typeface.create("sans-serif", Typeface.NORMAL);
                if (!fontPath.isEmpty()) { try { typeface = Typeface.createFromFile(new File(fontPath)); } catch (Throwable ignored) {} }
                paint.setTypeface(typeface); paint.setTextSize(size * canvas.getWidth() / 360f);
                canvas.save(); canvas.scale(scaleX,1f,x,y); String time = new SimpleDateFormat(DateFormat.is24HourFormat(CustomClockWallpaperService.this) ? "HH:mm" : "h:mm", Locale.getDefault()).format(new Date()); canvas.drawText(time,x,y,paint);
                if (p.getBoolean("date",true)) { paint.setTextSize(Math.max(12, size * canvas.getWidth()/360f * .23f)); String date = new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()); canvas.drawText(date,x,y + size*canvas.getWidth()/360f*.72f,paint); }
                canvas.restore();
            } catch (Throwable ignored) { } finally { if (canvas != null) try { holder.unlockCanvasAndPost(canvas); } catch (Throwable ignored) {} }
            if (visible) handler.postDelayed(drawTask, 1000L);
        }
    }
}
