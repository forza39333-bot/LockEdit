package com.lockedit.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private static final int REQUEST_CODE = 701;

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_CODE) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                js("window.onNativeResult && window.onNativeResult(true,'Доступ Shizuku разрешён');");
            } else {
                js("window.onNativeResult && window.onNativeResult(false,'Доступ Shizuku не выдан');");
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,8,9));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,8,9));
        Shizuku.addRequestPermissionResultListener(permissionListener);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(8,8,9));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "LockEdit");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String script) {
        main.post(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private boolean hasShizukuPermission() {
        try { return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    private class Bridge {
        @JavascriptInterface public void requestPermission() {
            main.post(() -> {
                try {
                    if (!Shizuku.pingBinder()) {
                        js("window.onNativeResult && window.onNativeResult(false,'Сначала запусти Shizuku');");
                        return;
                    }
                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                        js("window.onNativeResult && window.onNativeResult(true,'Shizuku уже подключён');");
                    } else {
                        Shizuku.requestPermission(REQUEST_CODE);
                    }
                } catch (Throwable t) {
                    js("window.onNativeResult && window.onNativeResult(false,'Не удалось запросить доступ Shizuku');");
                }
            });
        }

        @JavascriptInterface public void checkShizuku() {
            boolean running;
            boolean granted;
            try { running = Shizuku.pingBinder(); granted = running && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
            catch (Throwable t) { running = false; granted = false; }
            final boolean r = running, g = granted;
            js("window.onShizukuState && window.onShizukuState("+r+","+g+");");
        }

        @JavascriptInterface public void applyMode(String mode, int visibility, String colorHex) {
            if (!"full".equals(mode) && !"visibility".equals(mode)) return;
            String rgb = (colorHex == null ? "FFFFFF" : colorHex.replace("#", "").toUpperCase(java.util.Locale.US));
            if (!rgb.matches("[0-9A-F]{6}")) rgb = "FFFFFF";
            final String value = "full".equals(mode) ? fullTransparencyValue(rgb) : visibilityValue(visibility, rgb);
            worker.execute(() -> {
                if (!hasShizukuPermission()) {
                    js("window.onNativeResult && window.onNativeResult(false,'Нет разрешения Shizuku. Открой подключение и выдай доступ.');");
                    return;
                }
                try {
                    String quoted = "'" + value.replace("'", "'\\''") + "'";
                    String command = "for ns in secure system global; do if settings list \"$ns\" | grep -q '^lock_screen_custom_clock_face='; then settings put \"$ns\" lock_screen_custom_clock_face " + quoted + "; rc=$?; if [ $rc -eq 0 ]; then echo LOCKEDIT_OK:$ns; else echo LOCKEDIT_WRITE_FAILED:$ns; fi; exit $rc; fi; done; echo LOCKEDIT_KEY_NOT_FOUND; exit 2";
                    java.lang.reflect.Method method = Shizuku.class.getDeclaredMethod(
                        "newProcess", String[].class, String[].class, String.class
                    );
                    method.setAccessible(true);
                    Process process = (Process) method.invoke(
                        null, new String[]{"sh", "-c", command}, null, null
                    );
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    try (java.io.InputStream in = process.getInputStream()) { byte[] b = new byte[1024]; int n; while ((n = in.read(b)) > 0) out.write(b,0,n); }
                    try (java.io.InputStream in = process.getErrorStream()) { byte[] b = new byte[1024]; while (in.read(b) > 0) { } }
                    int exit = process.waitFor();
                    String result = new String(out.toByteArray(), StandardCharsets.UTF_8).trim();
                    if (exit == 0 && result.startsWith("LOCKEDIT_OK:")) {
                        String ns = result.substring("LOCKEDIT_OK:".length());
                        js("window.onNativeResult && window.onNativeResult(true,'Настройка записана в таблицу "+ns+". Если часы не обновились, перезагрузи телефон.');");
                    } else if (result.contains("LOCKEDIT_KEY_NOT_FOUND")) {
                        js("window.onNativeResult && window.onNativeResult(false,'Ключ не найден в System/Secure/Global. Нужна проверка таблицы SetEdit.');");
                    } else {
                        js("window.onNativeResult && window.onNativeResult(false,'Не удалось записать настройку. Проверь разрешение Shizuku.');");
                    }
                } catch (Throwable t) {
                    js("window.onNativeResult && window.onNativeResult(false,'Ошибка выполнения команды через Shizuku.');");
                }
            });
        }
    }

    private String fullTransparencyValue(String rgb) {
        long color = Long.parseLong(rgb, 16);
        return "{clockId:DIGITAL_CLOCK_CENTER,seedColor:"+color+",metadata:{metadataSelectedColorId:"+rgb+",appliedTimestamp:"+System.currentTimeMillis()+",metadataColorToneProgress:0},fontStylePath:default_typeface,seedColorType:"+rgb+",clockDataType:{darkLightColor:"+color+",shadowRadius:0,shadowDx:0,shadowDy:0,shadowColor:"+color+",dateShadowColor:"+color+",showDate:true,dateColor:"+color+",dateSize:1,positionY:4000,positionX:4000,fingerprintStyle:3,fingerprintVisible:0}}";
    }

    private String visibilityValue(int visibility, String rgb) {
        int v = Math.max(10, Math.min(100, visibility));
        int alpha = Math.round(v * 255f / 100f);
        String hex = String.format(java.util.Locale.US, "%02X%s", alpha, rgb);
        long color = (((long)alpha << 24) | Long.parseLong(rgb, 16));
        int signedColor = (int) color;
        long opaqueColor = Long.parseLong(rgb, 16);
        return "{clockId:DIGITAL_CLOCK_CENTER,seedColor:"+signedColor+",metadata:{appliedTimestamp:"+System.currentTimeMillis()+",metadataSelectedColorId:"+hex+",metadataColorToneProgress:100},fontStylePath:default_typeface,seedColorType:"+hex+",clockDataType:{darkLightColor:"+signedColor+",shadowRadius:0,shadowDx:0,shadowDy:0,shadowColor:"+opaqueColor+",dateShadowColor:"+opaqueColor+",showDate:false,dateColor:"+opaqueColor+",dateSize:1,positionY:4000,positionX:4000,fingerprintStyle:3,fingerprintVisible:0}}";
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        if (webView != null) { webView.removeJavascriptInterface("LockEdit"); webView.destroy(); webView = null; }
        worker.shutdownNow();
        super.onDestroy();
    }
}
