package com.lockedit.app;

import android.app.Activity;
import android.app.KeyguardManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private static final int REQUEST_CODE = 701;
    private final Handler rainbowHandler = new Handler(Looper.getMainLooper());
    private volatile boolean rainbowRunning = false;
    private volatile boolean rainbowSawLock = false;
    private int rainbowWaitTicks = 0;
    private int rainbowStep = 0;
    private int rainbowVisibility = 30;
    private String rainbowPosition = "DIGITAL_CLOCK_CENTER";
    private final Runnable rainbowTick = new Runnable() {
        @Override public void run() {
            if (!rainbowRunning) return;
            boolean locked = false;
            try {
                KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
                locked = km != null && km.isKeyguardLocked();
            } catch (Throwable ignored) { }
            if (locked) {
                rainbowSawLock = true;
                rainbowWaitTicks = 0;
                float hue = (rainbowStep++ * 8f) % 360f;
                int color = android.graphics.Color.HSVToColor(new float[]{hue, 1f, 1f});
                String hex = String.format(java.util.Locale.US, "%06X", color & 0xFFFFFF);
                String value = visibilityValue(rainbowVisibility, hex, rainbowPosition);
                worker.execute(() -> writeClockSetting(value, false));
            } else if (rainbowSawLock) {
                stopRainbowInternal();
                js("window.onRainbowStopped && window.onRainbowStopped('Переливание остановлено после разблокировки');");
                return;
            } else {
                rainbowWaitTicks++;
                if (rainbowWaitTicks > 30) {
                    stopRainbowInternal();
                    js("window.onRainbowStopped && window.onRainbowStopped('Переливание остановлено: телефон не был заблокирован');");
                    return;
                }
            }
            rainbowHandler.postDelayed(this, 1000L);
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_CODE) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                js("window.onNativeResult && window.onNativeResult(true,'Доступ Shizuku разрешён');");
            } else {
                js("window.onNativeResult && window.onNativeResult(false,'Доступ Shizuku не выдан');");
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,8,9));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,8,9));
        Shizuku.addRequestPermissionResultListener(permissionListener);
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(8,8,9));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "LockEdit");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void js(String script) {
        main.post(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private boolean hasShizukuPermission() {
        try { return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    private class Bridge {
        @JavascriptInterface public void requestPermission() {
            main.post(() -> {
                try {
                    if (!Shizuku.pingBinder()) {
                        js("window.onNativeResult && window.onNativeResult(false,'Сначала запусти Shizuku');");
                        return;
                    }
                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                        js("window.onNativeResult && window.onNativeResult(true,'Shizuku уже подключён');");
                    } else {
                        Shizuku.requestPermission(REQUEST_CODE);
                    }
                } catch (Throwable t) {
                    js("window.onNativeResult && window.onNativeResult(false,'Не удалось запросить доступ Shizuku');");
                }
            });
        }

        @JavascriptInterface public void checkShizuku() {
            boolean running;
            boolean granted;
            try { running = Shizuku.pingBinder(); granted = running && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
            catch (Throwable t) { running = false; granted = false; }
            final boolean r = running, g = granted;
            js("window.onShizukuState && window.onShizukuState("+r+","+g+");");
        }

        @JavascriptInterface public void startRainbow(int visibility, String position) {
            if (!hasShizukuPermission()) {
                js("window.onNativeResult && window.onNativeResult(false,'Нет разрешения Shizuku. Открой подключение и выдай доступ.');");
                return;
            }
            if (position == null || !(position.equals("DIGITAL_CLOCK_LEFT") || position.equals("DIGITAL_CLOCK_CENTER") || position.equals("DIGITAL_CLOCK_RIGHT") || position.equals("DIGITAL_CLOCK_LEFT_BIG_DATE"))) position = "DIGITAL_CLOCK_CENTER";
            rainbowVisibility = Math.max(10, Math.min(100, visibility));
            rainbowPosition = position;
            rainbowStep = 0;
            rainbowWaitTicks = 0;
            rainbowSawLock = false;
            rainbowRunning = true;
            rainbowHandler.removeCallbacks(rainbowTick);
            rainbowHandler.post(rainbowTick);
            js("window.onNativeResult && window.onNativeResult(true,'Переливание готово. Заблокируй телефон в течение 30 секунд.');");
        }

        @JavascriptInterface public void stopRainbow() {
            stopRainbowInternal();
            js("window.onRainbowStopped && window.onRainbowStopped('Переливание выключено');");
        }

        @JavascriptInterface public void applyMode(String mode, int visibility, String colorHex, String position) {
            if (!"full".equals(mode) && !"visibility".equals(mode)) return;
            if (position == null || !(position.equals("DIGITAL_CLOCK_LEFT") || position.equals("DIGITAL_CLOCK_CENTER") || position.equals("DIGITAL_CLOCK_RIGHT") || position.equals("DIGITAL_CLOCK_LEFT_BIG_DATE"))) position = "DIGITAL_CLOCK_CENTER";
            final String clockPosition = position;
            String rgb = (colorHex == null ? "FFFFFF" : colorHex.replace("#", "").toUpperCase(java.util.Locale.US));
            if (!rgb.matches("[0-9A-F]{6}")) rgb = "FFFFFF";
            final String value = "full".equals(mode) ? fullTransparencyValue(rgb, clockPosition) : visibilityValue(visibility, rgb, clockPosition);
            worker.execute(() -> writeClockSetting(value, true));
        }
    }

    private void stopRainbowInternal() {
        rainbowRunning = false;
        rainbowHandler.removeCallbacks(rainbowTick);
    }

    private void writeClockSetting(String value, boolean report) {
        if (!hasShizukuPermission()) {
            if (report) js("window.onNativeResult && window.onNativeResult(false,'Нет разрешения Shizuku. Открой подключение и выдай доступ.');");
            return;
        }
        try {
            String quoted = "'" + value.replace("'", "'\\''") + "'";
            String command = "for ns in secure system global; do if settings list \"$ns\" | grep -q '^lock_screen_custom_clock_face='; then settings put \"$ns\" lock_screen_custom_clock_face " + quoted + "; rc=$?; if [ $rc -eq 0 ]; then echo LOCKEDIT_OK:$ns; else echo LOCKEDIT_WRITE_FAILED:$ns; fi; exit $rc; fi; done; echo LOCKEDIT_KEY_NOT_FOUND; exit 2";
            java.lang.reflect.Method method = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            method.setAccessible(true);
            Process process = (Process) method.invoke(null, new String[]{"sh", "-c", command}, null, null);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (java.io.InputStream in = process.getInputStream()) { byte[] b = new byte[1024]; int n; while ((n = in.read(b)) > 0) out.write(b,0,n); }
            try (java.io.InputStream in = process.getErrorStream()) { while (in.read() != -1) { } }
            int exit = process.waitFor();
            String result = new String(out.toByteArray(), StandardCharsets.UTF_8).trim();
            if (report) {
                if (exit == 0 && result.startsWith("LOCKEDIT_OK:")) {
                    String ns = result.substring("LOCKEDIT_OK:".length());
                    js("window.onNativeResult && window.onNativeResult(true,'Настройка записана в таблицу "+ns+". Если часы не обновились, перезагрузи телефон.');");
                } else if (result.contains("LOCKEDIT_KEY_NOT_FOUND")) {
                    js("window.onNativeResult && window.onNativeResult(false,'Ключ не найден в System/Secure/Global. Нужна проверка таблицы SetEdit.');");
                } else js("window.onNativeResult && window.onNativeResult(false,'Не удалось записать настройку. Проверь разрешение Shizuku.');");
            }
        } catch (Throwable t) {
            if (report) js("window.onNativeResult && window.onNativeResult(false,'Ошибка выполнения команды через Shizuku.');");
        }
    }

    private String fullTransparencyValue(String rgb, String position) {
        long color = 0L;
        return "{clockId:"+position+",seedColor:"+color+",metadata:{metadataSelectedColorId:00"+rgb+",appliedTimestamp:"+System.currentTimeMillis()+",metadataColorToneProgress:0},fontStylePath:default_typeface,seedColorType:00"+rgb+",clockDataType:{darkLightColor:"+color+",shadowRadius:0,shadowDx:0,shadowDy:0,shadowColor:"+color+",dateShadowColor:"+color+",showDate:true,dateColor:"+color+",dateSize:1,positionY:4000,positionX:4000,fingerprintStyle:3,fingerprintVisible:0}}";
    }

    private String visibilityValue(int visibility, String rgb, String position) {
        int v = Math.max(10, Math.min(100, visibility));
        int alpha = Math.round(v * 255f / 100f);
        String hex = String.format(java.util.Locale.US, "%02X%s", alpha, rgb);
        long color = (((long)alpha << 24) | Long.parseLong(rgb, 16));
        int signedColor = (int) color;
        long opaqueColor = Long.parseLong(rgb, 16);
        return "{clockId:"+position+",seedColor:"+signedColor+",metadata:{appliedTimestamp:"+System.currentTimeMillis()+",metadataSelectedColorId:"+hex+",metadataColorToneProgress:100},fontStylePath:default_typeface,seedColorType:"+hex+",clockDataType:{darkLightColor:"+signedColor+",shadowRadius:0,shadowDx:0,shadowDy:0,shadowColor:"+opaqueColor+",dateShadowColor:"+opaqueColor+",showDate:false,dateColor:"+opaqueColor+",dateSize:1,positionY:4000,positionX:4000,fingerprintStyle:3,fingerprintVisible:0}}";
    }

    @Override protected void onDestroy() {
        stopRainbowInternal();
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        if (webView != null) { webView.removeJavascriptInterface("LockEdit"); webView.destroy(); webView = null; }
        worker.shutdownNow();
        super.onDestroy();
    }
}
